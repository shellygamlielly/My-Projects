
#ifndef FIND_THE_AUTHOR_WORDCOUNT_H
#define FIND_THE_AUTHOR_WORDCOUNT_H


#include <iostream>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <fstream>
#include <numeric>
#include <math.h>

/**
 *  A WordCount class.
 *  This class has vectors that count the number of appearances of frequent words in authors texts. It calculate the
 *  distances between unknown author vector to other in order to find the max match between texts of unknown author
 *  to other.
 */
class WordCount
{
private:
/**
 * A vector of integers that stores the number of appearances of frequent words in unknown author text
 */
    std::vector<int> _vec1;
/**
* A vector of integers that stores the number of appearances of frequent words in other author text
*/
    std::vector<int> _vec2;
/**
* A vector of strings that stores the text of the unknown author
*/
    std::vector<std::string> resultsAuthor;
/**
* A vector of strings that stores the text of other author
*/
    std::vector<std::string> resultsOther;

public:
/**
 * This method reads a text line by line, it changes all the letters in the texts to lowercase.
 * It splits the words in a line by the separators :  \",!;:\n\r, each time it inserts the words to a temporary vector,
 * and than it insert all the line in the file to a string vector.
 * @param fileName - the name of the file to read
 * @param myVector - the vector that holds all the sapereted words of unknown author or other authors.
 */
    void readText(const std::string& fileName , std::vector<std::string>& myVector);
/**
 * This method gets an unknown author text stored in a vector and a file of the frequent words.
 * It finds how many time each frequent word appears in the author text and put the number of appearances in a vector,
 * by the order that the frequent words were given.
 * @param fileName - the name of the file of the frequent words
 * @param myVector - an unknown author text contained in a vector
 * @param myIntVector-a vector that holds the number of appearances of each frequent word by the order they were given.
 */
    void countFreqWords(const std::string& fileName , std::vector<std::string>& myVect , std::vector<int>& intVector);
    /**
     * Get the private vector that holds the texts of unknown author
     * @return vector that holds the texts of unknown author
     */
    std::vector<std::string>& getResultsAuthor()
    {
        return resultsAuthor;
    }
    /**
     * Get the private vector that holds the texts of other author
     * @return vector that holds the texts of other author
     */
    std::vector<std::string>& getResultsOther()
    {
        return resultsOther;
    }
    /**
     * Get the private vector that holds the number of appearances of frequent words in the unknown author text
     * @return vector that holds the number of appearances of frequent words in the unknown author text
     */
    std::vector<int>& getVec1()
    {
        return _vec1;
    }
    /**
     * Get the private vector that holds the number of appearances of frequent words in the other author text
     * @return vector that holds the number of appearances of frequent words in the other author text
     */
    std::vector<int>& getVec2()
    {
        return _vec2;
    }
/**
 * This method calculate the distance between two vectors. This first vector is the one that holds the text of
 * unknown author , the second holds the text of other author.
 * It first calculates the dot product , than calculates each vector norm, and finally divide the dot product in the
 * multiplication of the vectors norms.
 * @param v1 - a vector that holds the text of unknown author
 * @param v2 -  a vector that holds the text of other author
 * @return the distance between two vectors.
 */
    double calculator(const std::vector<int> &v1 , const std::vector<int> &v2);
/**
 * This method gets a file of frequent words and a texts of other author,
 * read the other author texts and put it on vector.
 * It counts the number of appearances of each frequent word in the other author text and put it on a integers vector.
 * Than it calculates the distance between the unknown author vector and the other author vector and return the result.
 * It also clear the vector that represents the number of appearances of each frequent word in the other author text.
 * @param frequentWords - a file of frequent words to count in the other author text
 * @param other a texts of other author
 * @return the distance between the unknown author vector and the other author vector
 */
    double calculateScore(std::string& frequentWords , std::string& other);
};


#endif //FIND_THE_AUTHOR_WORDCOUNT_H
