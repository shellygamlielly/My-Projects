
#include "WordCount.h"
#include <iostream>
#include <vector>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <fstream>
#include <numeric>
#include <math.h>


/**
 *The main method gets at least 4 argument : the name of the program , a name of frequent word file ,  a name of
 * unknown author file ,  a name of other author file.
 * It reads the text of unknown author file and store it on string vetcor, it count the number of times a word from
 * frequent words file appears.
 * If there are 4 arguments it calculates the distance between a integers vector of unknown author and a integers vector
 * of other author. Than print the name of the other author file and the score (distance from unknown author vector).
 * if there are more than 4 argument it clears the string vector that stores the text of other author and repeat the
 * same actions as before (calculates the score and prints it).
 * Finally it prints a message with the best result of score and the name of the text of the other author.
 * @param argc - num of argument that were given
 * @param argv - the argument that were given
 * @return 0 if the code failed
 */
int main(int argc, char *argv[])
{
    if (argc < 4)
    {
        std::cerr << "Usage: find_the_author<frequent_words.txt> <text1> ..." << std::endl;
        return -1;
    }
    else
    {
        WordCount c;
        std::string frequentWords = argv[1];
        std::string unknown = argv[2];
        std::string other = argv[3];
        c.readText(unknown, c.getResultsAuthor());
        c.countFreqWords(frequentWords, c.getResultsAuthor(), c.getVec1());
        double maxRes = c.calculateScore(frequentWords, other);
        std::cout << other << " " << maxRes << std::endl;
        std::string author = " ";
        for (int i = 3; i < argc - 1; i++)
        {
            c.getResultsOther().clear();
            other = argv[i + 1];
            double res = c.calculateScore(frequentWords, other);
            std::cout << other << " " << res << std::endl;
            if (res >= maxRes)
            {
                maxRes = res;
                author = other + " ";
            }
        }
        std::cout << "Best matching author is " << author << "score " << maxRes << std::endl;
    }
    return 0;
}