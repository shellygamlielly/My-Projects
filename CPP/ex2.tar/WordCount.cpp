
#include "WordCount.h"

/**
 * This file contains the implementation of the class WordCount.h
 */
void WordCount::readText(const std::string &fileName, std::vector<std::string> &myVector)
{
    std::ifstream myFile(fileName);
    std::string line;
    if (myFile.is_open())
    {
        std::vector<std::string> temp;
        while (getline(myFile, line))
        {
            std::transform(line.begin(), line.end(), line.begin(), ::tolower);
            //should split by " ","\n","\t","!",";",","
            boost::split(temp, line, boost::is_any_of(" \",!;:\n\r"));
            myVector.insert(myVector.end(), temp.begin(), temp.end());
        }
    }

}

void WordCount::countFreqWords(const std::string &fileName, std::vector<std::string> &vect, std::vector<int> &intVector)
{
    std::ifstream myFile(fileName);
    std::string word;
    int count = 0;
    if (myFile.is_open())
    {
        while (getline(myFile, word))
        {
            if (!word.empty())
            {
                count = (int) std::count(vect.begin(), vect.end(), word);
            }
            intVector.push_back(count);

        }
        intVector.push_back(0);
    }
}

double WordCount::calculator(const std::vector<int> &v1, const std::vector<int> &v2)
{
    double dotProduct = std::inner_product(v1.begin(), v1.end(), v2.begin(), 0);
    double vec1Norm = sqrt(std::inner_product(v1.begin(), v1.end(), v1.begin(), 0));
    double vec2Norm = sqrt(std::inner_product(v2.begin(), v2.end(), v2.begin(), 0));
    double res = 0;
    if (vec1Norm == 0 || vec2Norm == 0)
    {
        res = 0;
    }
    else
    {
        res = dotProduct / (vec1Norm * vec2Norm);
    }
    return res;
}


double WordCount::calculateScore(std::string &frequentWords, std::string &other)
{
    readText(other, getResultsOther());
    countFreqWords(frequentWords, getResultsOther(), getVec2());
    double res = calculator(getVec1(), getVec2());
    getVec2().clear();
    return res;
}