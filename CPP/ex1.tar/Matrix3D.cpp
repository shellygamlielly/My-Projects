#include <iostream>
#include <string>
#include <cmath>
#include "Vector3D.h"
#include "Matrix3D.h"


// --------------------------------------------------------------------------------------
// This file contains the implementation of the class Matrix3D.
// --------------------------------------------------------------------------------------

/**
 *A constructor.
 *Initiate a matrix with zeros.
 */
Matrix3D::Matrix3D()
{
    this->setVec1(v1);
    this->setVec2(v2);
    this->setVec3(v3);
}

/**
 *A constructor that puts in the diagonal of the initiated matrix and zeros in all the other places.
 *@param num to put in the diagonal of the initiated matrix.
 */
Matrix3D::Matrix3D(double num)
{
    int i = 0;
    while (i < 3)
    {
        if (i == 0)
        {
            v1.setCordX(num);
            v2.setCordX(0);
            v3.setCordX(0);
            i++;
        }
        if (i == 1)
        {
            v1.setCordY(0);
            v2.setCordY(num);
            v3.setCordY(0);
            i++;
        }
        if (i == 2)
        {
            v1.setCordZ(0);
            v2.setCordZ(0);
            v3.setCordZ(num);
            i++;
        }
    }
}

/**
 *  A constructor that puts the givens numbers inside the matrix.
 * @param n1 - number to put in the matrix.
 * @param n2 - number to put in the matrix.
 * @param n3 - number to put in the matrix.
 * @param n4 - number to put in the matrix.
 * @param n5 - number to put in the matrix.
 * @param n6 - number to put in the matrix.
 * @param n7 - number to put in the matrix.
 * @param n8 - number to put in the matrix.
 * @param n9 - number to put in the matrix.
 */
Matrix3D::Matrix3D(double n1, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9)
{
    v1.setCordX(n1);
    v1.setCordY(n2);
    v1.setCordZ(n3);
    v2.setCordX(n4);
    v2.setCordY(n5);
    v2.setCordZ(n6);
    v3.setCordX(n7);
    v3.setCordY(n8);
    v3.setCordZ(n9);
}

/**
 * A constructor that puts the givens numbers meaning the arrays elements inside the matrix.
 * @param arr with 9 numbers to be inserted to the matrix.
 */
Matrix3D::Matrix3D(const double arr[9])
{
    v1.setCordX(arr[0]);
    v1.setCordY(arr[1]);
    v1.setCordZ(arr[2]);
    v2.setCordX(arr[3]);
    v2.setCordY(arr[4]);
    v2.setCordZ(arr[5]);
    v3.setCordX(arr[6]);
    v3.setCordY(arr[7]);
    v3.setCordZ(arr[8]);
}

/**
 * A constructor that puts the givens numbers meaning the arrays elements inside the matrix row by row.
 * @param arr with 3 rows and 3 column to be inserted to the matrix.
 */
Matrix3D::Matrix3D(const double arr[3][3])
{
    v1.setCordX(arr[0][0]);
    v1.setCordY(arr[0][1]);
    v1.setCordZ(arr[0][2]);
    v2.setCordX(arr[1][0]);
    v2.setCordY(arr[1][1]);
    v2.setCordZ(arr[1][2]);
    v3.setCordX(arr[2][0]);
    v3.setCordY(arr[2][1]);
    v3.setCordZ(arr[2][2]);
}

/**
 * A constructor that insert the given vectors inside the matrix row by row.
 * @param vec1 - vector to be inserted and the first row of the matrix.
 * @param vec2 - vector to be inserted and the second row of the matrix.
 * @param vec3 - vector to be inserted and the third row of the matrix.
 */
Matrix3D::Matrix3D(Vector3D &vec1, Vector3D &vec2, Vector3D &vec3)
{
    this->setVec1(vec1);
    this->setVec2(vec2);
    this->setVec3(vec3);

}

/**
 * A copy constructor
 * @param matrix to be copied.
 */
Matrix3D::Matrix3D(const Matrix3D &matrix)
{
    v1 = matrix.v1;
    v2 = matrix.v2;
    v3 = matrix.v3;
}


// ------------------ Operator methods ------------------------

/**
 * This method gets another Matrix and adds it to the current one
 * @param other
 * @return the current matrix after the operation
 */
Matrix3D &Matrix3D::operator+=(const Matrix3D &other)
{
    v1 += other.v1;
    v2 += other.v2;
    v3 += other.v3;
    return *this;
}

/**
 * This method gets another Matrix and subtracts it from the current one
 * @param other
 * @return the current matrix after the operation
 */
Matrix3D &Matrix3D::operator-=(const Matrix3D &other)
{
    v1 -= other.v1;
    v2 -= other.v2;
    v3 -= other.v3;
    return *this;
}

/**
 * This method gets a number and multiply it by the current matrix
 * @param num
 * @return the current matrix after the operation
 */
Matrix3D &Matrix3D::operator*=(const double num)
{
    v1 *= num;
    v2 *= num;
    v3 *= num;
    return *this;
}

/**
 * This method gets a number and divides it by the current matrix
 * @param num
 * @return the current matrix after the operation
 */
Matrix3D &Matrix3D::operator/=(const double num)
{
    if (num != 0)
    {
        v1 /= num;
        v2 /= num;
        v3 /= num;
    }
    else
    {
        std::cerr << "Invalid division by zero";
    }
    return *this;
}

/**
 * This method is responsible for printing a matrix
 * @param out is a stream
 * @param m is the matrix to be printed
 * @return the out stream
 */
std::ostream &operator<<(std::ostream &out, const Matrix3D &m)
{
    out << m.v1 << std::endl;
    out << m.v2 << std::endl;
    out << m.v3;
    return out;
}

/**
 * This method is responsible for printing a matrix after receving an array/2 dim array/3 vectors / 9 numbers
 * from the user
 * @param input is a stream to write to from user input
 * @param m is the matrix to be printed
 * @return the input stream
 */
std::istream &operator>>(std::istream &input, Matrix3D &m)
{
    input >> m.v1;
    input >> m.v2;
    input >> m.v3;
    return input;
}

/**
 * This method gets another Matrix and copies the vectors from the given matrix to the vector of the current one,
 * so they will be equal.
 * @param other
 * @return the current matrix after the placement operation
 */
Matrix3D &Matrix3D::operator=(const Matrix3D &m)
{
    v1 = m.v1;
    v2 = m.v2;
    v3 = m.v3;
    return *this;
}

/**
 * This method gets an index and  allows putting a vector inside one of the current matrix vectors
 * (depends on the index).
 * @param index to choose a vector from the matrix
 * @return a reference of the vector so we can operate placement meaning matrix[index] = newVector;
 */
Vector3D &Matrix3D::operator[](const int index)
{
    if (index == 0)
    {
        Vector3D &vec1 = v1;
        return vec1;
    }
    if (index == 1)
    {
        Vector3D &vec2 = v2;
        return vec2;
    }
    if (index == 2)
    {
        Vector3D &vec3 = v3;
        return vec3;
    }
    else
    {
        Vector3D &vec1 = v1;
        return vec1;
    }
}

/**
 * This method gets an index and allows us access this specific vector from the matrix depending on the index
 * @param index to access a vector from the matrix
 * @return a vector
 */
Vector3D Matrix3D::operator[](const int index) const
{
    if (index == 0)
    {
        return v1;
    }
    if (index == 1)
    {
        return v2;
    }
    if (index == 2)
    {
        return v3;
    } else
    {
        return v1;
    }
}

/**
 * This method gets another Matrix and multiply it by the current one
 * @param other - the matrix to multiply
 * @return a new Matrix3D that represent the result of the multiplication of the given matrix and the current one.
 */
Matrix3D Matrix3D::operator*(Matrix3D &other)
{
    Matrix3D m;
    for (int i = 0; i < 3; ++i)
    {

        if (i == 0)
        {
            m.v1.setCordX(row(0) * other.column(0));
            m.v1.setCordY(row(0) * other.column(1));
            m.v1.setCordZ(row(0) * other.column(2));
        }
        if (i == 1)
        {
            m.v2.setCordX(row(1) * other.column(0));
            m.v2.setCordY(row(1) * other.column(1));
            m.v2.setCordZ(row(1) * other.column(2));
        }
        if (i == 2)
        {
            m.v3.setCordX(row(2) * other.column(0));
            m.v3.setCordY(row(2) * other.column(1));
            m.v3.setCordZ(row(2) * other.column(2));
        }
    }
    return m;
}

/**
  * This method gets another Matrix and multiply it by the current one
  * @param other
  * @return the current matrix after the operation
  */
Matrix3D &Matrix3D::operator*=(Matrix3D &other)
{
    Matrix3D m = *this * other;
    setVec1(m.getVec1());
    setVec2(m.getVec2());
    setVec3(m.getVec3());
    return *this;
}

/**
 * This method gets another Matrix and adds it to the current one
 * @param other is the matrix to be added
 * @return a new matrix representing the result of the addition of the given matrix and the current one.
 */
Matrix3D Matrix3D::operator+(const Matrix3D &other)
{
    Matrix3D m;
    m.v1 = v1 + other.v1;
    m.v2 = v2 + other.v2;
    m.v3 = v3 + other.v3;
    return m;
}

/**
 * This method gets another Matrix and subtracts it from the current one
 * @param other is the matrix to be added
 * @return a new matrix representing the result of the subtraction of the given matrix and the current one.
 */
Matrix3D Matrix3D::operator-(const Matrix3D &other)
{
    Matrix3D m;
    m.v1 = v1 - other.v1;
    m.v2 = v2 - other.v2;
    m.v3 = v3 - other.v3;
    return m;
}

/**
 * This method gets another vECTOR and multiply it by the current matrix.
 * @param v the vector to multiply
 * @return a new vector that represent the result of the multiplication of the given vector and the current matrix.
 */
Vector3D Matrix3D::operator*(const Vector3D &v)
{
    Vector3D resultVec;
    resultVec.setCordX(row(0) * v);
    resultVec.setCordY(row(1) * v);
    resultVec.setCordZ(row(2) * v);
    return resultVec;
}

// ------------------ Other methods ------------------------

/**
     * This method returns the sum of the elements on the diagonal of the current matrix.
     * @return the sum of the elements on the diagonal
     */
double Matrix3D::trace()
{
    double num1 = v1.getCordX();
    double num2 = v2.getCordY();
    double num3 = v3.getCordZ();
    double sum = num1 + num2 + num3;
    return sum;
}


/**
 * This method calculates the determinant of the current matrix.
 * @return the determinant of the current matrix
 */
double Matrix3D::determinant()
{
    double res1 = v1.getCordX() * (v2.getCordY() * v3.getCordZ() - v2.getCordZ() * v3.getCordY());
    double res2 = v1.getCordY() * (v2.getCordX() * v3.getCordZ() - v2.getCordZ() * v3.getCordX());
    double res3 = v1.getCordZ() * (v2.getCordX() * v3.getCordY() - v2.getCordY() * v3.getCordX());
    double finalRes = res1 - res2 + res3;
    return finalRes;
}

/**
 * This method gets a number and returns the row of the matrix according to the row number.
 * In other words it returns the first/second/third vector on the matrix according to the index.
 * @param i - the number of the row that we want from the matrix
 * @return the row of the matrix according to the row number
 */
Vector3D Matrix3D::row(const short i)
{
    if (i == 0)
    {
        Vector3D &vec1 = v1;
        return vec1;
    }
    if (i == 1)
    {
        Vector3D &vec2 = v2;
        return vec2;
    }
    if (i == 2)
    {
        Vector3D &vec3 = v3;
        return vec3;
    }
    else
    {
        std::cerr << "Index out of bound" << std::endl;
        Vector3D &vec1 = v1;
        return vec1;
    }
}

/**
  * This method gets a number and returns the column of the matrix according to the row number.
  * @param i - the number of the column that we want from the matrix
  * @return the column of the matrix according to the column number.
  */
Vector3D Matrix3D::column(short i)
{
    Vector3D v;
    if (i > 2)
    {
        std::cerr << "Index out of bound" << std::endl;
    }
    else
    {
        if (i == 0)
        {
            v.setCordX(v1.getCordX());
            v.setCordY(v2.getCordX());
            v.setCordZ(v3.getCordX());

        }
        if (i == 1)
        {
            v.setCordX(v1.getCordY());
            v.setCordY(v2.getCordY());
            v.setCordZ(v3.getCordY());

        }
        if (i == 2)
        {
            v.setCordX(v1.getCordZ());
            v.setCordY(v2.getCordZ());
            v.setCordZ(v3.getCordZ());

        }
    }
    return v;
}


