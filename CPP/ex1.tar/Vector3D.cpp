#include <iostream>
#include <string>
#include <cmath>
#include "Vector3D.h"

// --------------------------------------------------------------------------------------
// This file contains the implementation of the class Vector3D.
// --------------------------------------------------------------------------------------

// Constructors
/**
 * A constructor.
 * Initiate a Vector3D with zeros in all coordinates.
 */
Vector3D::Vector3D()
{
    _x = 0;
    _y = 0;
    _z = 0;
}
/**
 * A constructor that initiates a vector with the given coordinates.
 * @param x - the coordinate to be inserted in the first place .
 * @param y - the coordinate to be inserted in the second place .
 * @param z - the coordinate to be inserted in the third place .
 */
Vector3D::Vector3D(double x, double y, double z)
{
    _x = x;
    _y = y;
    _z = z;
}
/**
 * A constructor that puts the givens numbers meaning the arrays elements inside the vector.
 * @param arr
 */
Vector3D::Vector3D(const double arr[3])
{
    _x = arr[0];
    _y = arr[1];
    _z = arr[2];
}
/**
 * A copy constructor
 * @param v2 is the vector to be copied.
 */
Vector3D::Vector3D(const Vector3D &v2)
{
    _x = v2._x;
    _y = v2._y;
    _z = v2._z;
}

// ------------------ Operator methods ------------------------
/**
 * This method gets another Vector3D and subtracts it from the current one
 * @param other is the vector to be subtracted
 * @return the current Vector3D after the operation
 */
Vector3D &Vector3D::operator+=(const Vector3D &other)
{
    _x += other._x;
    _y += other._y;
    _z += other._z;

    return *this;
}
/**
 * This method gets another Vector3D and subtracts it from the current one
 * @param other is the vector to be subtracted
 * @return the current Vector3D after the operation
 */
Vector3D &Vector3D::operator-=(const Vector3D &other)
{
    _x -= other._x;
    _y -= other._y;
    _z -= other._z;

    return *this;
}

/**
 * This method gets a number and adds it to the current vector
 * @param num is the number to be added
 * @return the current Vector3D after the operation
 */
Vector3D &Vector3D::operator+=(double num)
{
    _x += num;
    _y += num;
    _z += num;
    return *this;
}
/**
 * This method gets a number and subtracts it from the current vector
 * @param num is the number to be subtracted
 * @return the current Vector3D after the operation
 */
Vector3D &Vector3D::operator-=(double num)
{
    _x -= num;
    _y -= num;
    _z -= num;
    return *this;
}
/**
 * This method gets another Vector3D and adds it from the current one
 * @param v2 is the Vector3D to be added
 * @return a new Vector3D representing the result of the addition of the given Vector3D and the current one.
 */
Vector3D Vector3D::operator+(const Vector3D &v2)
{
    Vector3D v;
    v._x = _x + v2._x;
    v._y = _y + v2._y;
    v._z = _z + v2._z;
    return v;
}
/**
 * This method gets another Vector3D and subtracts it from the current one
 * @param v2 is the Vector3D to be subtract
 * @return a new Vector3D representing the result of the subtraction of the given Vector3D and the current one.
 */
Vector3D Vector3D::operator-(const Vector3D &v2)
{
    Vector3D v;
    v._x = _x - v2._x;
    v._y = _y - v2._y;
    v._z = _z - v2._z;
    return v;
}
/**
 * This method changes all the coordinates in the vector to negative numbers
 * @return minus of the current vector meaning  -(Vector3D)
 */
Vector3D Vector3D::operator-()
{
    Vector3D v;
    v.setCordX(getCordX() * -1);
    v.setCordY(getCordY() * -1);
    v.setCordZ(getCordZ() * -1);

    return v;
}
/**
 * This method gets a number and multiply it to the current vector
 * @param num is the number to be multiplied
 * @return the current Vector3D after the operation
 */
Vector3D Vector3D::operator*(const double num)
{
    Vector3D vector;
    vector._x = _x * num;
    vector._y = _y * num;
    vector._z = _z * num;
    return vector;
}
/**
 * This method gets a number and divides it by the current vector
 * @param num is the number to be divided
 * @return a new vector that represents the result of the division of the current vector and the number.
 */
Vector3D Vector3D::operator/(const double num)
{
    Vector3D vector;
    if(num!=0)
    {
        vector._x = _x / num;
        vector._y = _y / num;
        vector._z = _z / num;
    }
    else
    {
        std::cerr << "Invalid division by zero";
    }
    return vector;
}
/**
 * This method gets a number and  a vector and operate a multiplication of them.
 * @param num  - the number to multiply the vector
 * @param v - the vector
 * @return a new vector that represents the result of the multiplication of the given vector and the number.
 */
Vector3D operator*(const double num, const Vector3D &v)
{
    Vector3D vector;
    vector._x = v._x * num;
    vector._y = v._y * num;
    vector._z = v._z * num;
    return vector;
}
/**
 * This method gets a number and multiply it by the current Vector3D
 * @param num - to multiply the vector in
 * @return the current Vector3D after the operation
 */
Vector3D &Vector3D::operator*=(const double num)
{
    _x *= num;
    _y *= num;
    _z *= num;

    return *this;
}
/**
 * This method gets a number and divide it with the current Vector3D
 * @param num - to divide the vector in
 * @return the current Vector3D after the operation of division.
 */
Vector3D &Vector3D::operator/=(const double num)
{
    if(num!=0)
    {
        _x /= num;
        _y /= num;
        _z /= num;
    }
    else
    {
        std::cerr << "Invalid division by zero";
    }
    return *this;
}
/**
 * This method receives two vector (the current one and another) the calculates the distance between them
 * @param v - another vector to calculate the distance from the current one to it.
 * @return the distance from the current one vector to the other
 */
double Vector3D::operator|(const Vector3D &v)
{
    double dist = this->dist(v);
    return dist;
}
/**
 * This method receives two vector (the current one and another) the performs the dot product between them
 * @param v2 - the vector to be multiplied by the current one
 * @return dot product between current vector and another one.
 */
double Vector3D::operator*(const Vector3D &v2)
{
    double cordX = _x * v2._x;
    double cordY = _y * v2._y;
    double cordZ = _z * v2._z;
    double result = cordX + cordY + cordZ;
    return result;
}
/**
 * This method calculates the angle between 2 vectors using dot product and cos
 * @param v2 -other vector
 * @return the angle between 2 vectors
 */
double Vector3D::operator^(Vector3D &v2)
{
    double v1Size = this->norm();
    double v2Size = v2.norm();
    double tempRes = v1Size * v2Size;
    double dotProduct = *(this) * v2;
    double result = dotProduct / tempRes;
    double finalRes = acos(result);
    return finalRes;
}
/**
 * This method is responsible for printing a vector
 * @param out is a stream
 * @param v is the vector to be printed
 * @return the out stream
 */
std::ostream &operator<<(std::ostream &out, const Vector3D &v)
{
    out << v._x << " " << v._y << " " << v._z;
    return out;
}
/**
 * This method is responsible for printing a Vector3D after receving an array/3 coordinates /3 numbers from the user
 * @param input is a stream to write to from user input
 * @param v is the vector to be printed
 * @return the input stream
 */
std::istream &operator>>(std::istream &input, Vector3D &v)
{
    input >> v._x;
    input >> v._y;
    input >> v._z;
    return input;
}
/**
 * This method gets another Vector3D and copies the coordinates from the given Vector3D to the coordinates
 * of the current one, so they will be equal.
 * @param other is a vector to perform a palcement
 * @return the current vector after the placement operation.
 */
Vector3D &Vector3D::operator=(const Vector3D &v)
{
    setCordX(v._x);
    setCordY(v._y);
    setCordZ(v._z);
    return *this;
}

/**
 * This method gets an index and  allows putting a coordinate inside one of the current vectors coordiantes
 * (depends on the index).
 * @param index to choose a coordinate from the vector
 * @return a reference of the coordinate so we can operate placement meaning vector[index] = newValue;
 */
double &Vector3D::operator[](const int index)
{
    if (index == 0)
    {
        double &cordX = _x;
        return cordX;
    }
    if (index == 1)
    {
        double &cordY = _y;
        return cordY;
    }
    if (index == 2)
    {
        double &cordZ = _z;
        return cordZ;
    }
    else
    {
        std::cerr << "Index out of bounds";
        return this->_x;
    }
}
/**
* This method gets an index and allows us access this specific coordinate from the vector depending on the index
* @param index to access a coordinate from the vector
* @return a coordinate value
*/
double Vector3D::operator[](int index) const
{
    return arr[index];
}

// ------------------ Other methods ------------------------
/**
 * Calculates the length of the vector from distance 0
 * @return the length of the vector
 */
double Vector3D::norm()
{
    double vectorSize = pow(_x, 2) + pow(_y, 2) + pow(_z, 2);
    double result = pow(vectorSize, 0.5);
    return result;
}

/**
 * calculate distance from the current vector to the given one.
 * @param v is a vector to calculate distance from
 * @return distance from the current vector to the given one.
 */
double Vector3D::dist(const Vector3D &v)
{
    double deltaX = pow(_x - v._x, 2);
    double deltaY = pow(_y - v._y, 2);
    double deltaZ = pow(_z - v._z, 2);
    double res = deltaX + deltaY + deltaZ;
    double dist = pow(res, 0.5);
    return dist;
}

