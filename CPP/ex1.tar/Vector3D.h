#include <iostream>
#include <string>
#include <cmath>

#ifndef VECTOR3D_H
#define VECTOR3D_H

/**
 *  A Vector3D class.
 *  This class represents a vector with (x,y,z) coordinates.
 */
class Vector3D
{
private:
    double _x; /**< the x coordinate. Details. */
    double _y; /**< the y coordinate. Details. */
    double _z; /**< the z coordinate. Details. */
    double arr[3] = {0, 0, 0}; /**< an array with 3 doubles. Details. */

public:
    /**
     * A constructor.
     * Initiate a Vector3D with zeros in all coordinates.
     */
    Vector3D();

    /**
     * A constructor that initiates a vector with the given coordinates.
     * @param x - the coordinate to be inserted in the first place .
     * @param y - the coordinate to be inserted in the second place .
     * @param z - the coordinate to be inserted in the third place .
     */
    Vector3D(double x, double y, double z);

    /**
     * A constructor that puts the givens numbers meaning the arrays elements inside the vector.
     * @param arr
     */
    Vector3D(const double arr[3]);

    /**
     * A copy constructor
     * @param v2 is the vector to be copied.
     */
    Vector3D(const Vector3D &v2);

    /**
	 * Access method for the x coordinate .
	 * @return The x coordinate
	 */
    double getCordX() { return _x; }

    /**
* Setting method for the x coordinate in order to give it a new value .
*/
    void setCordX(double num) { _x = num; }

    /**
	 * Access method for the y coordinate .
	 * @return The y coordinate
	 */
    double getCordY() { return _y; }

    /**
    * Setting method for the y coordinate in order to give it a new value .
    */
    void setCordY(double num) { _y = num; }

    /**
	 * Access method for the z coordinate .
	 * @return The z coordinate
	 */
    double getCordZ() { return _z; }

    /**
* Setting method for the z coordinate in order to give it a new value .
*/
    void setCordZ(double num) { _z = num; }

    /**
     * This method gets another Vector3D and adds it from the current one
     * @param v2 is the Vector3D to be added
     * @return a new Vector3D representing the result of the addition of the given Vector3D and the current one.
     */
    Vector3D operator+(const Vector3D &v2);

    /**
     * This method gets another Vector3D and subtracts it from the current one
     * @param v2 is the Vector3D to be subtract
     * @return a new Vector3D representing the result of the subtraction of the given Vector3D and the current one.
     */
    Vector3D operator-(const Vector3D &v2);

    /**
     * This method gets another Vector3D and adds it to the current one
     * @param other is the vector to be added
     * @return a new Vector3D after the operation
     */
    Vector3D &operator+=(const Vector3D &other);

    /**
     * This method gets another Vector3D and subtracts it from the current one
     * @param other is the vector to be subtracted
     * @return the current Vector3D after the operation
     */
    Vector3D &operator-=(const Vector3D &other);

    /**
     * This method gets a number and adds it to the current vector
     * @param num is the number to be added
     * @return the current Vector3D after the operation
     */
    Vector3D &operator+=(double num);

    /**
     * This method gets a number and subtracts it from the current vector
     * @param num is the number to be subtracted
     * @return the current Vector3D after the operation
     */
    Vector3D &operator-=(double num);

    /**
     * This method changes all the coordinates in the vector to negative numbers
     * @return minus of the current vector meaning  -(Vector3D)
     */
    Vector3D operator-();

    /**
     * This method gets a number and multiply it to the current vector
     * @param num is the number to be multiplied
     * @return the current Vector3D after the operation
     */
    Vector3D operator*(double num);

    /**
     * This method gets a number and  a vector and operate a multiplication of them.
     * @param num  - the number to multiply the vector
     * @param v - the vector
     * @return a new vector that represents the result of the multiplication of the given vector and the number.
     */
    friend Vector3D operator*(double num, const Vector3D &v);

    /**
     * This method gets a number and divides it by the current vector
     * @param num is the number to be divided
     * @return a new vector that represents the result of the division of the current vector and the number.
     */
    Vector3D operator/(double num);

    /**
     * This method gets a number and multiply it by the current Vector3D
     * @param num - to multiply the vector in
     * @return the current Vector3D after the operation
     */
    Vector3D &operator*=(double num);

    /**
     * This method gets a number and divide it with the current Vector3D
     * @param num - to divide the vector in
     * @return the current Vector3D after the operation of division.
     */
    Vector3D &operator/=(double num);

    /**
     * This method receives two vector (the current one and another) the calculates the distance between them
     * @param v - another vector to calculate the distance from the current one to it.
     * @return the distance from the current one vector to the other
     */
    double operator|(const Vector3D &v);

    /**
     * This method receives two vector (the current one and another) the performs the dot product between them
     * @param v2 - the vector to be multiplied by the current one
     * @return dot product between current vector and another one.
     */
    double operator*(const Vector3D &v2);

    /**
     * This method calculates the angle between 2 vectors using dot product and cos
     * @param v2 -other vector
     * @return the angle between 2 vectors
     */
    double operator^(Vector3D &v2);

    /**
     * This method is responsible for printing a vector
     * @param out is a stream
     * @param v is the vector to be printed
     * @return the out stream
     */
    friend std::ostream &operator<<(std::ostream &out, const Vector3D &v);

    /**
     * This method is responsible for printing a Vector3D after receving an array/3 coordinates /3 numbers from the user
     * @param input is a stream to write to from user input
     * @param v is the vector to be printed
     * @return the input stream
     */
    friend std::istream &operator>>(std::istream &input, Vector3D &v);

    /**
     * This method gets another Vector3D and copies the coordinates from the given Vector3D to the coordinates
     * of the current one, so they will be equal.
     * @param other is a vector to perform a palcement
     * @return the current vector after the placement operation.
     */
    Vector3D &operator=(const Vector3D &v);

    /**
     * This method gets an index and  allows putting a coordinate inside one of the current vectors coordiantes
     * (depends on the index).
     * @param index to choose a coordinate from the vector
     * @return a reference of the coordinate so we can operate placement meaning vector[index] = newValue;
     */
    double &operator[](int index);

    /**
    * This method gets an index and allows us access this specific coordinate from the vector depending on the index
    * @param index to access a coordinate from the vector
    * @return a coordinate value
    */
    double operator[](int index) const;

    /**
     * Calculates the length of the vector from distance 0
     * @return the length of the vector
     */
    double norm();

    /**
     * calculate distance from the current vector to the given one.
     * @param v is a vector to calculate distance from
     * @return distance from the current vector to the given one.
     */
    double dist(const Vector3D &v);
};


#endif