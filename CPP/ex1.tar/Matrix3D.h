#include <iostream>
#include <string>
#include <cmath>
#include "Vector3D.h"

#ifndef MATRIX3D_H
#define MATRIX3D_H


/**
 *  A Matrix3D class.
 *  This class represents a matrix 3D with (v1,v2,v3) vectors.
 */
class Matrix3D
{
private:
    Vector3D v1 = {0, 0, 0};
    Vector3D v2 = {0, 0, 0};
    Vector3D v3 = {0, 0, 0};
    Vector3D _matrix[3];
public:
    /**
     * A constructor.
     * Initiate a matrix with zeros.
     */
    Matrix3D();

    /**
     * A constructor that puts in the diagonal of the initiated matrix and zeros in all the other places.
     * @param num to put in the diagonal of the initiated matrix.
     */
    Matrix3D(double num);

    /**
     *  A constructor that puts the givens numbers inside the matrix.
     * @param n1 - number to put in the matrix.
     * @param n2 - number to put in the matrix.
     * @param n3 - number to put in the matrix.
     * @param n4 - number to put in the matrix.
     * @param n5 - number to put in the matrix.
     * @param n6 - number to put in the matrix.
     * @param n7 - number to put in the matrix.
     * @param n8 - number to put in the matrix.
     * @param n9 - number to put in the matrix.
     */
    Matrix3D(double n1, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9);

    /**
     * A constructor that puts the givens numbers meaning the arrays elements inside the matrix.
     * @param arr with 9 numbers to be inserted to the matrix.
     */
    Matrix3D(const double arr[9]);

    /**
     * A constructor that puts the givens numbers meaning the arrays elements inside the matrix row by row.
     * @param arr with 3 rows and 3 column to be inserted to the matrix.
     */
    Matrix3D(const double arr[3][3]);

    /**
     * A constructor that insert the given vectors inside the matrix row by row.
     * @param vec1 - vector to be inserted and the first row of the matrix.
     * @param vec2 - vector to be inserted and the second row of the matrix.
     * @param vec3 - vector to be inserted and the third row of the matrix.
     */
    Matrix3D(Vector3D &vec1, Vector3D &vec2, Vector3D &vec3);

    /**
     * A copy constructor
     * @param matrix to be copied.
     */
    Matrix3D(const Matrix3D &matrix);

    /**
	 * Access method for the vector v1 .
	 * @return The vector v1
	 */
    Vector3D getVec1() { return v1; }

    /**
	 * Setting method for the vector v1 in order to give it a new value .
	 */
    void setVec1(const Vector3D &other) { v1 = other; }

    /**
	 * Access method for the vector v2 .
	 * @return The vector v2
	 */
    Vector3D getVec2() { return v2; }

    /**
	 * Setting method for the vector v2 in order to give it a new value .
	 */
    void setVec2(const Vector3D &other) { v2 = other; }

    /**
	 * Access method for the vector v3 .
	 * @return The vector v3
	 */
    Vector3D getVec3() { return v3; }

    /**
	 * Setting method for the vector v3 in order to give it a new value .
	 */
    void setVec3(const Vector3D &other) { v3 = other; }

    /**
     * This method gets another Matrix and adds it to the current one
     * @param other
     * @return the current matrix after the operation
     */
    Matrix3D &operator+=(const Matrix3D &other);

    /**
     * This method gets another Matrix and subtracts it from the current one
     * @param other
     * @return the current matrix after the operation
     */
    Matrix3D &operator-=(const Matrix3D &other);

    /**
     * This method gets a number and multiply it by the current matrix
     * @param num
     * @return the current matrix after the operation
     */
    Matrix3D &operator*=(double num);

    /**
     * This method gets another Matrix and multiply it by the current one
     * @param other
     * @return the current matrix after the operation
     */
    Matrix3D &operator*=(Matrix3D &other);

    /**
     * This method gets a number and divides it by the current matrix
     * @param num
     * @return the current matrix after the operation
     */
    Matrix3D &operator/=(double num);

    /**
     * This method is responsible for printing a matrix
     * @param out is a stream
     * @param m is the matrix to be printed
     * @return the out stream
     */
    friend std::ostream &operator<<(std::ostream &out, const Matrix3D &m);

    /**
     * This method is responsible for printing a matrix after receving an array/2 dim array/3 vectors / 9 numbers
     * from the user
     * @param input is a stream to write to from user input
     * @param m is the matrix to be printed
     * @return the input stream
     */
    friend std::istream &operator>>(std::istream &input, Matrix3D &m);

    /**
     * This method gets another Matrix and copies the vectors from the given matrix to the vector of the current one,
     * so they will be equal.
     * @param other
     * @return the current matrix after the placement operation
     */
    Matrix3D &operator=(const Matrix3D &m);

    /**
     * This method gets an index and  allows putting a vector inside one of the current matrix vectors
     * (depends on the index).
     * @param index to choose a vector from the matrix
     * @return a reference of the vector so we can operate placement meaning matrix[index] = newVector;
     */
    Vector3D &operator[](int index);

    /**
     * This method gets an index and allows us access this specific vector from the matrix depending on the index
     * @param index to access a vector from the matrix
     * @return a vector
     */
    Vector3D operator[](int index) const;

    /**
     * This method gets another Matrix and multiply it by the current one
     * @param other - the matrix to multiply
     * @return a new Matrix3D that represent the result of the multiplication of the given matrix and the current one.
     */
    Matrix3D operator*(Matrix3D &other);

    /**
     * This method gets another vECTOR and multiply it by the current matrix.
     * @param v the vector to multiply
     * @return a new vector that represent the result of the multiplication of the given vector and the current matrix.
     */
    Vector3D operator*(const Vector3D &v);

    /**
     * This method gets another Matrix and adds it to the current one
     * @param other is the matrix to be added
     * @return a new matrix representing the result of the addition of the given matrix and the current one.
     */
    Matrix3D operator+(const Matrix3D &other);

    /**
     * This method gets another Matrix and subtracts it from the current one
     * @param other is the matrix to be added
     * @return a new matrix representing the result of the subtraction of the given matrix and the current one.
     */
    Matrix3D operator-(const Matrix3D &other);

    /**
     * This method gets a number and returns the row of the matrix according to the row number.
     * In other words it returns the first/second/third vector on the matrix according to the index.
     * @param i - the number of the row that we want from the matrix
     * @return the row of the matrix according to the row number
     */
    Vector3D row(short i);

    /**
     * This method gets a number and returns the column of the matrix according to the row number.
     * @param i - the number of the column that we want from the matrix
     * @return the column of the matrix according to the column number.
     */
    Vector3D column(short i);

    /**
     * This method returns the sum of the elements on the diagonal of the current matrix.
     * @return the sum of the elements on the diagonal
     */
    double trace();

    /**
     * This method calculates the determinant of the current matrix.
     * @return the determinant of the current matrix
     */
    double determinant();

};

#endif