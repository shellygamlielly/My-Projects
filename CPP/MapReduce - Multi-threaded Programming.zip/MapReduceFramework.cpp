
#include "MapReduceClient.h"
#include "Barrier.h"
#include <iostream>
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <atomic>
#include <algorithm>
#include <semaphore.h>

#define MAIN_THREAD 0
#define EXIT 1
#define PERCENTAGE 100
#define ERROR_PTHREAD_MUTEX_LOCK_MSG  "Error on pthread_mutex_lock"
#define ERROR_PTHREAD_MUTEX_UNLOCK_MSG "Error on pthread_mutex_unlock"
#define ERROR_SEM_WAIT_MSG "ERROR: sem_wait failed"
#define ERROR_PTHREAD_MUTEX_INIT_MSG "Error on pthread_mutex_init"
#define ERROR_SEM_INTT_MSG  "Error on sem_init"
#define ERROR_PTHREAD_CREATE "ERROR: pthread_create() failed"
#define ERROR_MUTEX_DESTROY_MSG "Error on mutex destroy"


using namespace std;

typedef void* JobHandle;

enum stage_t {UNDEFINED_STAGE=0, MAP_STAGE=1, REDUCE_STAGE=2};

typedef struct {
    stage_t stage;
    float percentage;
} JobState;

struct ThreadContext;

struct jobContext
{
    std::atomic<unsigned int> *counter;
    std::atomic<unsigned int> *counterReduce;
    std::atomic<unsigned int> *numOfKeys;
    InputVec *inputVec;
    OutputVec *outputVec;
    IntermediateVec *intermediateVec;
    MapReduceClient *client;

    sem_t *sem;
    std::vector<std::vector<std::pair<K2 *, V2 *>>> beforeShuffle;
    std::vector<std::vector<std::pair<K2 *, V2 *>> > ShuffleQueue;
    ThreadContext **thread_context;

    int threadLevel = 0;
    pthread_t *threads;
    JobState *job_state;
    pthread_mutex_t *ShuffleQueue_mutex;
    pthread_mutex_t *beforeShuffle_mutex;
    pthread_mutex_t *emit2_mutex;
    pthread_mutex_t *emit3_mutex;
    pthread_mutex_t *job_state_mutex;
    Barrier *barrier;
    bool isShufflePhaseFinished;
    bool isJoin;
};

struct ThreadContext
{
    IntermediateVec afterMapVec;
    int id;
    jobContext *job_context;
};


void emit2(K2 *key, V2 *value, void *context)
{
    ThreadContext *threadCon = (ThreadContext *) context;
    if (pthread_mutex_lock(threadCon->job_context->emit2_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
        exit(EXIT);
    }
    (threadCon->afterMapVec).push_back(IntermediatePair(key, value));
    if (pthread_mutex_unlock(threadCon->job_context->emit2_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
        exit(EXIT);
    }

}

void emit3(K3 *key, V3 *value, void *context)
{
    jobContext *jobCon = (jobContext *) context;
    if (pthread_mutex_lock(jobCon->emit3_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
        exit(EXIT);
    }

    (jobCon->outputVec)->push_back(OutputPair(key, value));

    if (pthread_mutex_unlock(jobCon->emit3_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
        exit(EXIT);
    }

}

bool comparator(std::pair<K2 *, V2 *> p1, std::pair<K2 *, V2 *> p2)
{
    return *(p1.first) < *(p2.first);
}

/**
 * starts mapping and sorting the input
 * @param context
 */
void MapPhase(void *context)
{

    ThreadContext *threadCon = (ThreadContext *) context;
    unsigned int oldVal;
    while (true)
    {
        oldVal = (*(threadCon->job_context->counter))++;
        if (oldVal < threadCon->job_context->inputVec->size())
        {

            if (pthread_mutex_lock(threadCon->job_context->job_state_mutex) != 0)
            {
                std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
                exit(EXIT);
            }
            threadCon->job_context->job_state->stage = MAP_STAGE;
            threadCon->job_context->job_state->percentage =
                    ((float) oldVal / (float) (threadCon->job_context->inputVec->size())) * PERCENTAGE;
            if (pthread_mutex_unlock(threadCon->job_context->job_state_mutex) != 0)
            {
                std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
                exit(EXIT);
            }


            threadCon->job_context->client->map(((threadCon->job_context->inputVec)->begin() + oldVal)->first,
                                                ((threadCon->job_context->inputVec)->begin() + oldVal)->second,
                                                threadCon);
        } else {


            if (pthread_mutex_lock(threadCon->job_context->job_state_mutex) != 0)
            {
                std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
                exit(EXIT);
            }
            threadCon->job_context->job_state->stage = MAP_STAGE;
            threadCon->job_context->job_state->percentage = PERCENTAGE;
            if (pthread_mutex_unlock(threadCon->job_context->job_state_mutex) != 0)
            {
                std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
                exit(EXIT);
            }
            break;
        }


    }
    std::sort(threadCon->afterMapVec.begin(), threadCon->afterMapVec.end(), comparator);

    if (pthread_mutex_lock(threadCon->job_context->beforeShuffle_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
        exit(EXIT);
    }
    threadCon->job_context->beforeShuffle.push_back(threadCon->afterMapVec);
    if (pthread_mutex_unlock(threadCon->job_context->beforeShuffle_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
        exit(EXIT);
    }


}

/**
 * This function find the max key
 * @param context
 * @return
 */
K2 *findMaxKey(void *context)
{
    jobContext *jobCon = (jobContext *) context;
    K2 *maxKey;
    std::pair<K2 *, V2 *> p;
    for (long unsigned int i = 0; i < jobCon->beforeShuffle.size(); i++)
    {
        if (!(jobCon->beforeShuffle.begin() + i)->empty())
        {
            p = (jobCon->beforeShuffle.begin()+i)->back();
            break;
        }

    }

    maxKey = p.first;
    for (auto tempVec : jobCon->beforeShuffle)
    {
        if (!tempVec.empty())
        {
            pair<K2 *, V2 *> tempPair = tempVec.back();
            if (comparator(p, tempPair))
            {
                maxKey = tempPair.first;
                p=tempPair;
            }
        }
        else
        {
            break;
        }


    }
    return maxKey;
}
/**
 * starts This function start the shuffle phase
 * @param context
 */
void ShufflePhase(void *context)
{

    ThreadContext *thread_context = (ThreadContext *) context;

    while (!(thread_context->job_context->beforeShuffle.empty()))
    {

        IntermediateVec sequence ;

        K2 *cur_key = findMaxKey(thread_context->job_context);

        std::vector<unsigned int> int_sequence;
        for (unsigned int j = 0; j < thread_context->job_context->beforeShuffle.size(); ++j)
        {
            if (thread_context->job_context->beforeShuffle.at(j).empty())
            {
                int_sequence.emplace_back(j);
                break;
            }
            while (!(thread_context->job_context->beforeShuffle.at(j).empty()) &&
                   (!((*(thread_context->job_context->beforeShuffle.at(j).back().first)) < (*cur_key) ||
                      (*cur_key)<(*(thread_context->job_context->beforeShuffle.at(j).back().first)))))
            {
                sequence.emplace_back(thread_context->job_context->beforeShuffle.at(j).back());
                thread_context->job_context->beforeShuffle.at(j).pop_back();

                if (thread_context->job_context->beforeShuffle.at(j).empty())
                {
                    int_sequence.emplace_back(j);
                    break;
                }
            }
        }
        if (pthread_mutex_lock(thread_context->job_context->ShuffleQueue_mutex) != 0)
        {
            std::cerr<< ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
            exit(EXIT);
        }
        thread_context->job_context->ShuffleQueue.emplace_back(sequence);
        if (pthread_mutex_unlock(thread_context->job_context->ShuffleQueue_mutex) != 0) {
            std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
            exit(EXIT);
        }

        sem_post(thread_context->job_context->sem);
        long size = int_sequence.size();
        for (int k = 0; k < size; ++k)
        {
            int cur_num = int_sequence.back();
            int_sequence.pop_back();
            thread_context->job_context->beforeShuffle.erase(thread_context->job_context->beforeShuffle.begin() + cur_num);
        }

    }

    for (int i = 0; i < thread_context->job_context->threadLevel; ++i)
    {
        sem_post(thread_context->job_context->sem);
    }
    thread_context->job_context->isShufflePhaseFinished = true;
}

/**
 * This function start the reduce phase - processing the output keys
 * @param context
 */
void ReducePhase(void *context)
{

    jobContext *jobCon = (jobContext *) context;
    if (sem_wait(jobCon->sem) != 0)
    {
        std::cerr << ERROR_SEM_WAIT_MSG << std::endl;
        exit(EXIT);
    }

    unsigned int oldVal;
    unsigned int keys = (*(jobCon->numOfKeys));
    oldVal = (*(jobCon->counterReduce))++;


    while (!(jobCon->isShufflePhaseFinished) ||
            oldVal < jobCon->ShuffleQueue.size())
    {
        if (sem_wait(jobCon->sem) != 0)

        {
            std::cerr << ERROR_SEM_WAIT_MSG << std::endl;
            exit(EXIT);
        }
        if (!jobCon->ShuffleQueue.empty())
        {
            if (pthread_mutex_lock(jobCon->job_state_mutex) != 0)
            {
                std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
                exit(EXIT);
            }
            jobCon->job_state->stage = REDUCE_STAGE;
            jobCon->job_state->percentage = ((float) oldVal / (float) keys) * PERCENTAGE;
            if (pthread_mutex_unlock(jobCon->job_state_mutex) != 0) {
                std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
                exit(EXIT);
            }
            if((oldVal < jobCon->ShuffleQueue.size()) && !(jobCon->ShuffleQueue.at(oldVal).empty()))
            {
                jobCon->client->reduce(&(jobCon->ShuffleQueue[oldVal]), jobCon);
            }


            oldVal = (*(jobCon->counterReduce))++;

        }
    }


    if (pthread_mutex_lock(jobCon->job_state_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_LOCK_MSG<<std::endl;
        exit(EXIT);
    }
    jobCon->job_state->stage = REDUCE_STAGE;
    jobCon->job_state->percentage = PERCENTAGE;
    if (pthread_mutex_unlock(jobCon->job_state_mutex) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_UNLOCK_MSG<<std::endl;
        exit(EXIT);
    }
}

/**
 * This function has the thread's job - mapping, shuffling, and reducing.
 * @param context
 * @return
 */
void *handler(void *context)
{
    ThreadContext *thread_context = (ThreadContext *) context;
    MapPhase(thread_context);

    thread_context->job_context->barrier->barrier();
    if (thread_context->id == MAIN_THREAD)
    {
        for (long unsigned int i = 0; i < (thread_context->job_context->beforeShuffle).size(); i++)
        {
            (*(thread_context->job_context->numOfKeys)) += ((thread_context->job_context->beforeShuffle.begin() +
                                                             i))->size();
        }
        ShufflePhase(thread_context);
    }
    ReducePhase(thread_context->job_context);

    return nullptr;
}

/**
 * This function starts the job - create the threads and returns the job context object
 * @param client - the client
 * @param inputVec - input of the job
 * @param outputVec - output of the job
 * @param multiThreadLevel -  number of the threads
 * @return job contxt
 */
JobHandle startMapReduceJob(const MapReduceClient &client,
                            const InputVec &inputVec, OutputVec &outputVec,
                            int multiThreadLevel)
{
    jobContext *job_context = new jobContext();
    job_context->counter = new std::atomic<unsigned int>(0);
    job_context->counterReduce = new std::atomic<unsigned int>(0);
    job_context->numOfKeys = new std::atomic<unsigned int>(0);
    job_context->barrier = new Barrier(multiThreadLevel);

    job_context->intermediateVec = new std::vector<std::pair<K2 *, V2 *>>;

    job_context->emit2_mutex = new pthread_mutex_t;
    job_context->emit3_mutex = new pthread_mutex_t;
    job_context->job_state_mutex = new pthread_mutex_t;
    job_context->beforeShuffle_mutex = new pthread_mutex_t;
    job_context->ShuffleQueue_mutex = new pthread_mutex_t;

    job_context->thread_context = new ThreadContext*[multiThreadLevel];

    if (pthread_mutex_init(job_context->emit2_mutex, nullptr) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_INIT_MSG<<std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_init(job_context->emit3_mutex, nullptr) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_INIT_MSG<<std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_init(job_context->beforeShuffle_mutex, nullptr) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_INIT_MSG<<std::endl;
        exit(EXIT);
    }

    if (pthread_mutex_init(job_context->ShuffleQueue_mutex, nullptr) != 0)
    {
        std::cerr<< ERROR_PTHREAD_MUTEX_INIT_MSG<<std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_init(job_context->job_state_mutex, nullptr) != 0)
    {
        std::cerr<<ERROR_PTHREAD_MUTEX_INIT_MSG<<std::endl;
        exit(EXIT);
    }


    job_context->threads = new pthread_t[multiThreadLevel];

    job_context->inputVec = (InputVec *) &inputVec;
    job_context->outputVec = &outputVec;

    job_context->isShufflePhaseFinished = false;
    job_context->isJoin = false;

    job_context->sem = new sem_t;
    if (sem_init(job_context->sem, 0, 0) != 0)
    {
        std::cerr<<ERROR_SEM_INTT_MSG<<std::endl;
        exit(EXIT);
    }

    job_context->client = (MapReduceClient *) &client;
    job_context->threadLevel = multiThreadLevel;
    job_context->job_state = new JobState();
    job_context->job_state->stage = UNDEFINED_STAGE;
    job_context->job_state->percentage = 0;

    int rc;
    for (int t = 0; t < multiThreadLevel; t++)
    {
        ThreadContext *threadCon = new ThreadContext;
        threadCon->id = t;
        threadCon->job_context = job_context;
        job_context->thread_context[t] = threadCon;

        rc = pthread_create(&threadCon->job_context->threads[t], nullptr, &handler,
                            threadCon->job_context->thread_context[t]);
        if (rc)
        {
            std::cerr << ERROR_PTHREAD_CREATE << rc << std::endl;
            exit(EXIT);
        }
    }


    return job_context;

}

/**
 * This function waits for the job to finish.
 * @param job
 */
void waitForJob(JobHandle job)
{
    jobContext *jobCon = (jobContext *) job;
    if (jobCon->isJoin)
    {
        return;
    }
    jobCon->isJoin = true;
    for (int i = 0; i < jobCon->threadLevel; i++)
    {

        if (pthread_join(jobCon->threads[i], nullptr) != 0)
        {
            std::cerr << errno << "Error: pthread_join failed" << std::endl;
            exit(EXIT);
        }
    }
}

/**
 * This function puts the current job state into the given job state
 * @param job
 * @param state
 */
void getJobState(JobHandle job, JobState *state)
{
    jobContext *jobCon = (jobContext *) job;
    *state = *(jobCon->job_state);
}

/**
 * This function closes the running threads and delete the allocated memory.
 * @param job
 */
void closeJobHandle(JobHandle job)
{
    jobContext *jobCon = (jobContext *) job;
    waitForJob(jobCon);

    for (int i = 0; i < jobCon->threadLevel; i++)
    {
        delete jobCon->thread_context[i];


    }

    if (pthread_mutex_destroy(jobCon->job_state_mutex) != 0)
    {
        std::cerr << ERROR_MUTEX_DESTROY_MSG << std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_destroy(jobCon->emit3_mutex) != 0)
    {
        std::cerr << ERROR_MUTEX_DESTROY_MSG << std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_destroy(jobCon->beforeShuffle_mutex) != 0)
    {
        std::cerr << ERROR_MUTEX_DESTROY_MSG << std::endl;
        exit(EXIT);
    }
    if (pthread_mutex_destroy(jobCon->emit2_mutex) != 0)
    {
        std::cerr << ERROR_MUTEX_DESTROY_MSG << std::endl;
        exit(1);
    }
    if (sem_destroy(jobCon->sem) != 0)
    {
        std::cerr << ERROR_MUTEX_DESTROY_MSG << std::endl;
        exit(EXIT);
    }

    delete jobCon->counter;
    delete jobCon->counterReduce;
    delete jobCon->numOfKeys;
    delete jobCon->sem;
    delete jobCon->intermediateVec;
    delete jobCon->barrier;
    delete jobCon->job_state;
    delete jobCon->emit2_mutex;
    delete jobCon->emit3_mutex;
    delete jobCon->job_state_mutex;
    delete jobCon->ShuffleQueue_mutex;
    delete jobCon->beforeShuffle_mutex;
    delete[] jobCon->thread_context;
    delete[] jobCon->threads;
    delete jobCon;

}