
#ifndef EX3_MATRIX_H
#define EX3_MATRIX_H

#include <iostream>
#include <vector>
#include <cstdlib>
#include <string.h>
#include <stdexcept>
#include <numeric>
#include "Complex.h"
#include <complex>
#include <exception>


template<class T>
/**
 *A class Matrix with template T that could be any type (int/double/complex) as elements of the matrix
 * @tparam T type of the elements in the matrix int/double/complex
 */
class Matrix
{
    /**
     * Error messages when throwing MatrixException
     */
    std::string ILLEGAL_ADD = "Got MatrixException with message:\"cannot addition matrices of different sizes.\"";
    std::string ILLEGAL_SUB = "Got MatrixException with message:\"cannot subtract matrices of different sizes.\"";
    std::string ILLEGAL_TRANS = "Got Exception from Matrix::trans() with message:\"cannot transpose a matrix which isn't square\"";
    std::string ILLEGAL_ROW_OR_COL = "Got MatrixException with message:\"there are not enough, or there are too many items in the input vector\"";
    /**
     * A MatrixException class is an inner class of Matrix that represents the exception that might occur
     */
    class MatrixException : public std::exception
    {

    private:
        std::string _msg;
    public:
        explicit MatrixException(std::string msg)
        {
            _msg = msg;
        }
        virtual const char *what() const throw()
        {
            return _msg.c_str();
        }
    };

private:
    /**
     * The number of columns in the matrix
     */
    unsigned int numOfCols;
    /**
     * The number of rows in the matrix
     */
    unsigned int numOfRows;
    /**
     * The number of element in the matrix
     */
    unsigned int numOfElem;
    /**
     * A matrix implemented as vector
     */
    std::vector<T> _matrix;

public:
    /**
     * Get the number of element in a matrix
     * @return number of element in a matrix
     */
    unsigned int getNumOfElem() const { return numOfElem; }

    /**
     * Set the number of element in a matrix
     */
    void setNumOfElem(unsigned int num) { numOfElem = num; }

    /**
     * Set the number of columns in a matrix
     */
    void setNumOfCols(unsigned int num) { numOfCols = num; }

    /**
     * Set the number of rows in a matrix
     */
    void setNumOfRows(unsigned int num) { numOfRows = num; }

    //Constructor
    Matrix();

    /**
     * Construct a matrix with number of rows and columns as given, and set each cell with 0.
     * Throw an exception (MatrixException) if the given number of rows or cols are negative.
     * @param rows - number of rows
     * @param cols - number of columns
     */
    Matrix(unsigned int rows, unsigned int cols);

    //Copy Constructor
    Matrix(const Matrix &newMat);

    /**
     * Construct a matrix with number of rows and columns as given, and set each cell with the vector elements.
     * Throw an exception (MatrixException) if the given number of rows or cols are negative.
     * @param rows - number of rows
     * @param cols - number of columns
     * @param cells - a vector to set its elements in a matrix
     */
    Matrix(unsigned int rows, unsigned int cols, const std::vector<T> &cells);

    //Destructor
    ~Matrix() = default ;

    /**
     * @return the number of rows in a given matrix
     */
    unsigned int rows() const { return numOfRows; }

    /**
     * @return the number of columns in a given matrix
     */
    unsigned int cols() const { return numOfCols; }

    /**
     * @param other - another matrix to compare to.
     * @return true if this matrix is equal to other matrix, and false otherwise.
     */
    inline bool operator==(const Matrix &other)
    { return _matrix == other._matrix && numOfCols == other.numOfCols && numOfRows == other.numOfRows; }

    /**
     * @param other - another matrix to compare to.
     * @return true if this matrix is not equal to other matrix, and false otherwise.
     */
    inline bool operator!=(const Matrix &other) { return !(*this == other); }

    /**
     * Assignment operator returns a reference of a matrix that has the same elements
     * (number of roes and number of columns) as the given one.
     * @param m - matrix to be assigned to current matrix.
     * @return a reference of a matrix that has the same elements as the given one.
     */
    Matrix &operator=(const Matrix &m);

    /**
     * Addition operator returns a matrix with the addition of elements from the current matrix and other matrix.
     * Throws an exception (MatrixException) if the number of rows/columns of a given matrix is diffrent from the number
     * of rows/columns of a current one
     * @param other - a matrix to be added to the current one
     * @return a matrix with the addition of elements from the current matrix and other matrix.
     */
    Matrix operator+(const Matrix &other);

    /**
     * subtract operator returns a matrix with the Subtraction of elements of the current matrix and other matrix.
     * Throws an exception (MatrixException) if the number of rows/columns of a given matrix is diffrent from the number
     * of rows/columns of a current one.
     * @param other - a matrix to subtract from the current one
     * @return a matrix with the Subtraction of elements of the current matrix and other matrix.
     */
    Matrix operator-(const Matrix &other);

    /**
     *operator to access specif cell in a matrix.
     * Throws an exception (out_of_range) if the number of rows/columns of that were given is bigger than the number
     * of rows-1/columns-1 of a current one. Or if the given number of rows or columns are negative.
     * @param row - the index of the row to access
     * @param col - the index of the column to access
     * @return a specific cell of the matrix by the row index and the column index-  matrix[row][column]
     */
    T operator()(const unsigned int &row, const unsigned int &col) const;

    /**
     *operator to assign to specif cell in a matrix.
     * Throws an exception (out_of_range) if the number of rows/columns of that were given is bigger than the number
     * of rows-1/columns-1 of a current one. Or if the given number of rows or columns are negative.
     * @param row - the index of the row of the matrix
     * @param col - the index of the column of the matrix
     * @return a reference to specific cell of the matrix by the row index and the column index-
     * example : matrix[row][column] = 5
     */
    T &operator()(const unsigned int &row, const unsigned int &col);

    /**
     * Multiplication opeartor of matrix with the Iterative algorithm:
        C = AB for an n × m matrix A and an m × p matrix B, then C is an n × p matrix with entries
     * Throws an exception (MatrixException) if the number of rows of a given matrix is different from the number
     * of columns of a current one
     * @param other - the other matrix to multiply with the current one
     * @return a matrix that represents the result of multiplying matrix row by column.
     */
    Matrix operator*(const Matrix &other);

    /**
     * Printing operator - The overloads of operator>> that take a std::ostream& as the left hand argument and prints a
     * given matrix row by row;
     * @tparam M  - the type of the elements in the matrix
     * @param out - the output stream
     * @param mat - the matrix to be printed
     * @return the output stream of the matrix row by row
     */
    template<typename M>
    friend std::ostream &operator<<(std::ostream &out, const Matrix<M> &mat);

    /**
     * This method check if the matrix is squared meaning the number of rows is equal to the number of columns.
     * @return true if the matrix is squared and false otherwise.
     */
    bool isSquareMatrix() const { return numOfCols == numOfRows; }

    /**
     * This method returns the transposed matrix of the current matrix.
     * Throws an exception (MatrixException) if the number of rows of a current matrix is different from the number
     * of columns of a current one (if the current matrix is not squared).
     * @return the transposed matrix of the current matrix.
     */
    Matrix trans () const;



    /**
     * An iterator that points to the first element in the matrix
     * @return
     */
    auto begin() const { return _matrix.cbegin(); }

    /**
     * An iterator that points to the next element after the last element in the matrix
     * @return
     */
    auto end() const { return _matrix.cend(); }

};

template<typename T>
Matrix<T>::Matrix()
{
    numOfElem = 1;
    numOfCols = 1;
    numOfRows = 1;
    _matrix = std::vector<T>(numOfElem, 0);
}

template<typename T>
Matrix<T>::Matrix(unsigned int rows, unsigned int cols)
{
    if ((int) rows < 0 || (int) cols < 0)
    {
        throw MatrixException(ILLEGAL_ROW_OR_COL);
    }
    numOfCols = cols;
    numOfRows = rows;
    numOfElem = numOfRows * numOfCols;
    _matrix = std::vector<T>(numOfElem, 0);
}

template<typename T>
Matrix<T>::Matrix(const Matrix &newMat)
{
    numOfElem = newMat.numOfElem;
    numOfCols = newMat.numOfCols;
    numOfRows = newMat.numOfRows;
    _matrix = newMat._matrix;
}

template<typename T>
Matrix<T>::Matrix(unsigned int rows, unsigned int cols, const std::vector<T> &cells)
{
    if ((int) rows < 0 || (int) cols < 0)
    {
        throw MatrixException(ILLEGAL_ROW_OR_COL);
    }
    numOfCols = cols;
    numOfRows = rows;
    numOfElem = numOfRows * numOfCols;
    if (rows == cols || rows * cols == cells.size())
    {
        _matrix = cells;
    }
    else
    {
        _matrix.resize(numOfElem);
        for (unsigned int i = 0; i < numOfElem; i++)
        {
            _matrix[i] = cells[i];
        }
    }
}


template<typename T>
Matrix<T> &Matrix<T>::operator=(const Matrix<T> &m)
{
    if (this == &m)
    {
        return *this;
    }
    numOfElem = m.numOfElem;
    numOfCols = m.numOfCols;
    numOfRows = m.numOfRows;
    _matrix = m._matrix;
    return *this;
}

template<typename T>
Matrix<T> Matrix<T>::operator+(const Matrix<T> &other)
{
    if (numOfRows != other.numOfRows || numOfCols != other.numOfCols)
    {
        throw Matrix::MatrixException(ILLEGAL_ADD);
    }

    Matrix m = Matrix(numOfRows, numOfCols);
    for (unsigned int i = 0; i < numOfElem; ++i)
    {
        m._matrix[i] = _matrix[i] + other._matrix[i];
    }
    return m;
}



template<typename T>
Matrix<T> Matrix<T>::operator-(const Matrix &other)
{
    if (numOfRows != other.numOfRows || numOfCols != other.numOfCols)
    {
        throw Matrix::MatrixException(ILLEGAL_SUB);
    }
    Matrix m = Matrix(numOfRows, numOfCols);
    for (unsigned int i = 0; i < numOfElem; ++i)
    {
        m._matrix[i] = _matrix[i] - other._matrix[i];
    }
    return m;
}

template<typename T>
T Matrix<T>::operator()(const unsigned int &row, const unsigned int &col) const
{
    if (row > numOfRows - 1 || col > numOfCols - 1 || numOfRows < 0 || numOfCols < 0)
    {
        throw std::out_of_range("Matrix::operator() : out of range error at index ");
    }
    return _matrix[numOfCols * row + col];
}

template<typename T>
T &Matrix<T>::operator()(const unsigned int &row, const unsigned int &col)
{
    if (row > numOfRows - 1 || col > numOfCols - 1 || numOfRows < 0 || numOfCols < 0)
    {
        throw std::out_of_range("Matrix::operator() : out of range error at index ");
    }
    return _matrix[numOfCols * row + col];
}

template<typename T>
Matrix<T> Matrix<T>::operator*(const Matrix &other)
{
    Matrix m = Matrix(numOfRows, other.numOfCols);
    if (numOfCols != other.numOfRows || numOfRows != other.numOfCols)
    {
        throw std::out_of_range("Matrix::operator* : out of range error cannot multiply matrix"
                                " of different number of row or different number of cols ");
    }
    for (unsigned int i = 0; i < numOfRows; i++)
    {
        for (unsigned int j = 0; j < other.numOfCols; j++)
        {
            T sum = 0;
            for (unsigned int k = 0; k < numOfCols; k++)
            {
                T res = _matrix[numOfCols * i + k] * other(k, j);
                sum += res;
            }
            m(i, j) = sum;
        }
    }
    return m;
}


template<typename M>
std::ostream &operator<<(std::ostream &out, const Matrix<M> &mat)
{
    for (unsigned int i = 0; i < mat.numOfRows; ++i)
    {
        for (unsigned int j = 0; j < mat.numOfCols; ++j)
        {
            out << mat(i, j) << "\t";
        }
        out << "\n";
    }
    return out;
}


template<typename T>
Matrix<T> Matrix<T>::trans() const
{
    Matrix m = Matrix(numOfRows, numOfCols);
    if (!isSquareMatrix())
    {
        throw MatrixException(ILLEGAL_TRANS);
    }
    for (unsigned int i = 0; i < numOfRows; ++i)
    {
        for (unsigned int j = 0; j < numOfCols; ++j)
        {
            m(i, j) = _matrix[numOfRows * j + i];
        }
    }
    return m;
}


template<>
Matrix<Complex> Matrix<Complex>::trans() const
{
    Matrix<Complex> m = Matrix(numOfRows, numOfCols);
    if (!isSquareMatrix())
    {
        throw MatrixException(ILLEGAL_TRANS);
    }
    for (unsigned int i = 0; i < numOfRows; ++i)
    {
        for (unsigned int j = 0; j < numOfCols; ++j)
        {
            Complex temp = _matrix[numOfCols * i + j].conj();
            m(j, i) = temp;
        }
    }
    return m;
}


#endif //EX3_MATRIX_H
