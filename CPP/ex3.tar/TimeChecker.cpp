

#include <iostream>
#include <chrono>
#include <iostream>
#include <fstream>
#include <numeric>
#include <math.h>
#include <stack>
#include <string>
#include <cstdlib>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <ctime>
#include <chrono>
#include <eigen3/Eigen/Dense>
#include "Matrix.hpp"
#include <vector>


/**
 * tictoc_stack is used for time checking
 */
std::stack<std::chrono::time_point<std::chrono::system_clock>> tictoc_stack;

/**
 * This method is called before executing an operation so we could know what is the starting time
 */
void tic()
{
    tictoc_stack.push(std::chrono::system_clock::now());
}

/**
 * This method is called after executing an operation when elapsed_seconds is the difference between before operation
 * and after
 * @param msg - is the message to appear each time we calculate the time it took to multiply of add matrices.
 */
void toc(std::string msg)
{
    std::chrono::duration<double> elapsed_seconds = std::chrono::system_clock::now() - tictoc_stack.top();
    std::cout << msg << elapsed_seconds.count() << std::endl;
    tictoc_stack.pop();
}

/**
 * The main function gets a number as an argument ,creates a random matrix using eigen library.
 * Than calculate the time to execute add operation and multiply operation and print it.
 * Latter on it creates a matrix using Matrix class that I implemented ,than it calculate the time to execute add
 * operation and multiply operation and print it.
 * @param argc  - the number of arguments that were given
 * @param argv - a list of the arguments that were given
 * @return 0 if an error occure
 */
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        std::cerr << "Usage: must provide at least one argument ..." << std::endl;
        return -1;
    }
    else
    {
        std::string num = argv[1];
        std::cout << "size " << num << std::endl;
        std::string::size_type sz;
        int n = std::stoi(num, &sz);
        Eigen::MatrixXd m1 = Eigen::MatrixXd::Random(n, n);
        Eigen::MatrixXd m2 = Eigen::MatrixXd::Random(n, n);

        auto numOfRows = (unsigned int) n;
        std::vector<int> vec = std::vector<int>(n * n, 1);
        Matrix<int> mat1 = Matrix<int>(numOfRows, numOfRows, vec);
        Matrix<int> mat2 = Matrix<int>(mat1);


        tic();
        m1 * m2;
        toc("eigen mult ");
        tic();
        m1 + m2;
        toc("eigen add ");

        tic();
        mat1 * mat2;
        toc("matlib mult ");
        tic();
        mat1 + mat2;
        toc("matlib add ");


    }
    return 0;
}
