CREATE TABLE bestsellers(
Name VARCHAR,
Author VARCHAR,
User_Rating FLOAT(3),
Reviews INTEGER,
Price INTEGER,
Year INTEGER,
Genre VARCHAR);